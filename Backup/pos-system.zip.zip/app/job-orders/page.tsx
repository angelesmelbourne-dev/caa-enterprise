"use client";

import { useState } from "react";

export default function JobOrdersPage() {
  const [customerName, setCustomerName] = useState("");
  const [plateNumber, setPlateNumber] = useState("");
  const [complaint, setComplaint] = useState("");
  const [notes, setNotes] = useState("");

  return (
    <div className="min-h-screen bg-zinc-950 text-white">

      <div className="max-w-7xl mx-auto p-8">

        <h1 className="text-3xl font-bold">
          Job Orders
        </h1>

        <p className="text-zinc-400 mt-2">
          Manage repair jobs and service requests.
        </p>

        <div
          className="
            mt-8
            rounded-2xl
            border
            border-zinc-800
            bg-zinc-900
            p-6
          "
        >

          <div className="grid gap-4">

            <input
              type="text"
              placeholder="Customer Name"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              className="
    rounded-lg
    border
    border-zinc-700
    bg-zinc-950
    px-4
    py-3
  "
            />

            <input
              type="text"
              placeholder="Vehicle Plate Number"
              value={plateNumber}
              onChange={(e) => setPlateNumber(e.target.value)}
              className="
    rounded-lg
    border
    border-zinc-700
    bg-zinc-950
    px-4
    py-3
  "
            />

            <input
              type="text"
              placeholder="Customer Complaint"
              value={complaint}
              onChange={(e) => setComplaint(e.target.value)}
              className="
                rounded-lg
                border
                border-zinc-700
                bg-zinc-950
                px-4
                py-3
              "
            />

            <textarea
              placeholder="Technician Notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="
                rounded-lg
                border
                border-zinc-700
                bg-zinc-950
                px-4
                py-3
              "
            />

            <button
              className="
                rounded-xl
                bg-emerald-600
                px-5
                py-3
                font-medium
                hover:bg-emerald-700
              "
            >
              Save Job Order
            </button>

          </div>

        </div>

        <div className="mt-8">

          <h2 className="text-xl font-semibold mb-4">
            Job Order List
          </h2>

          <div
            className="
              rounded-xl
              border
              border-zinc-800
              bg-zinc-900
              p-4
            "
          >
            <h3 className="font-semibold">
              JO-0001
            </h3>

            <p className="text-zinc-400">
              Engine oil change
            </p>

            <p className="text-zinc-500 text-sm">
              Status: Open
            </p>
          </div>

        </div>

      </div>

    </div>
  );
}